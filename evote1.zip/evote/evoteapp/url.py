from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
    path('',views.index, name='index'),
    path('lagislative/',views.lagislative_page,name='lagislative'),
    path('parliament/',views.parliament_page,name='parliament'),
    path('userlogin/',views.userlogin,name='userlogin'),
    path('register/',views.register,name='register'),
    path('BJP/',views.BJP,name='BJP'),
    path('BSP/',views.BSP,name='BSP'),
    path('Congress/',views.Congress,name='Congress'),
    path('SP/',views.SP,name='SP'),
    path('AAP/', views.Aapdetail, name='AAP'),
    path('404error',views.errorpage,name='404error'),
    path('handlelogout',views.handlelogout,name='handlelogout'),
    path('result',views.result,name="result")


]
