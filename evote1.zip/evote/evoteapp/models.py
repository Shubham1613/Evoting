
from django.db import models
from django.contrib.auth.models import User
# Create your models here.



class Parliamentvoting(models.Model):
    name = models.CharField(max_length=20, default='')
    numberofvote = models.IntegerField(default='0')
    description = models.CharField(max_length=1000,default="")
    image = models.ImageField(upload_to="evote/images")
    def __str__(self):
        return self.name


class Lagislative_voting(models.Model):
    name = models.CharField(max_length=20)
    numberofvote = models.IntegerField(default='0')
    description = models.CharField(max_length=1000,default='')
    image = models.ImageField(upload_to="evote/images")
    def __str__(self):
        return self.name
class candidate_detail(models.Model):
    c_name = models.CharField(max_length=50)
    age = models.IntegerField(default="25")
    birthplace = models.CharField(max_length=500)
    qualifications = models.CharField(max_length=500)
    partyname = models.CharField(max_length=100)
    political_career = models.CharField(max_length=1000)
    speciality = models.CharField(max_length=1000)
    elect_type = models.CharField(max_length=200)
    count_vote = models.IntegerField(default='0')
    result = models.CharField(max_length=50)
    image = models.ImageField(upload_to="evote/images")
    def __str__(self):
        return self.c_name


class regis_user(models.Model):
    id = models.CharField(max_length=10,default='',primary_key=True)
    name = models.CharField(max_length=100,default="")
    #last_name = models.CharField(max_length=30)
    fathers_name = models.CharField(max_length=30,default="")
    mothers_name = models.CharField(max_length=30,default="")
    mobileno = models.IntegerField(default='')
    aadharno = models.IntegerField(default='')
    #aadharno = models.ForeignKey(User, on_delete=models.CASCADE)
    voter_id = models.CharField(max_length=50,default='')
    email = models.EmailField(default='')
    password = models.CharField(max_length=100,default="")
    dob = models.CharField(max_length=30,default="")
    gender = models.CharField(max_length=50,default="")
    occupation = models.CharField(max_length=100,default="")
    address = models.CharField(max_length=1000,default='')
    city = models.CharField(max_length=100,default='')
    State = models.CharField(max_length=100,default='')
    zipcode = models.IntegerField(default='')
    nationality = models.CharField(max_length=100,default='')
    category = models.CharField(max_length=20,default='')
    Religious = models.CharField(max_length=100,default='hindu')
    vote_status = models.BooleanField(default=False)
    #document files

    aadhar_image = models.ImageField(upload_to="Evote/images", default='')
    voterid_image = models.ImageField(upload_to="Evote/images",default='')
    signature_image = models.ImageField(upload_to="Evote/images",default='')
    u_image= models.ImageField(upload_to="Evote/images", default='')

    def __str__(self):
        return self.name
