from django.apps import AppConfig


class EvoteappConfig(AppConfig):
    name = 'evoteapp'
