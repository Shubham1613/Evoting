from django.contrib import admin

# Register your models here.
from . import models
admin.site.register(models.Parliamentvoting)
admin.site.register(models.Lagislative_voting)
admin.site.register(models.regis_user)
admin.site.register(models.candidate_detail)
