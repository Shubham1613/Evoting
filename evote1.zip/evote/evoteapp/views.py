from django.shortcuts import render,redirect
from .models import Parliamentvoting,Lagislative_voting,regis_user,candidate_detail
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User, auth
from django.http import HttpResponse
from django.contrib import messages


def index(request):
    return render(request,'evote/index1.html')
def homepage(request):
    return render(request,'evote/homepage.html')
def lagislative_page(request):
    parties=Lagislative_voting.objects.all()
    return render(request,'evote/lagislative.html', {'party':parties})
def parliament_page(request):
    parties=Parliamentvoting.objects.all()
    #cover_image = cover_image.objects.all()
    return render(request,'evote/parliament.html', {'party':parties})

def userlogin(request):
    if request.method == 'POST' :
        userid = request.POST['aadhar']
        password = request.POST['password']

        user = authenticate(username=userid,password=password)


        if user is not None:
            login(request,user)
            messages.success(request,"successfully loged in")
            return redirect('index')
            # Redirect to a success page.
        else:

            # Return an 'invalid login' error message.
            print('wrong')
            return  redirect("userlogin")
    else:
        return render(request,'evote/login.html')
def handlelogout(request):
    logout(request)
    return redirect('index')


def BJP(request):
    data = candidate_detail.objects.filter(partyname = 'BJP')

    if request.method == 'POST':
        if request.user.is_active :
            count = request.POST['hvote']
            c=int(count)
            c +=1
            status='done'
            d = candidate_detail.objects.filter(partyname='BJP').update(count_vote=c)
            return redirect('BJP')
        else:
            return redirect("userlogin")
    else:

        return render(request,'evote/detail.html',{'data' : data})
def Congress(request):
    data = candidate_detail.objects.filter(partyname = 'Congress')

    if request.method == 'POST':
        if request.user.is_active :
            count = request.POST['hvote']
            c=int(count)
            c +=1
            status='done'
            d = candidate_detail.objects.filter(partyname='Congress').update(count_vote=c)
            return redirect('Congress')
        else:
            return redirect("userlogin")
    else:

        return render(request,'evote/detail.html',{'data' : data})
def SP(request):
    data = candidate_detail.objects.filter(partyname = 'SP')

    if request.method == 'POST':
        if request.user.is_active :
            count = request.POST['hvote']
            c=int(count)
            c +=1
            status='done'
            d = candidate_detail.objects.filter(partyname='SP').update(count_vote=c)
            return redirect('SP')
        else:
            return redirect("userlogin")
    else:

        return render(request,'evote/detail.html',{'data' : data})
def BSP(request):
    data = candidate_detail.objects.filter(partyname = 'BSP')

    if request.method == 'POST':
        if request.user.is_active :
            count = request.POST['hvote']
            c=int(count)
            c +=1
            status='done'
            d = candidate_detail.objects.filter(partyname='SP').update(count_vote=c)
            return redirect('BSP')
        else:
            return redirect("userlogin")
    else:

        return render(request,'evote/detail.html',{'data' : data})
def Aapdetail(request):
    data = candidate_detail.objects.filter(partyname = 'AAP')

    if request.method == 'POST':
        if request.user.is_active :
            count = request.POST['hvote']
            c=int(count)
            c +=1
            status='done'
            d = candidate_detail.objects.filter(partyname='AAP').update(count_vote=c)
            return redirect('AAP')
        else:
            return redirect("userlogin")
    else:

        return render(request,'evote/detail.html',{'data' : data})
def register(request):
    if request.method=='POST':
        f_name=request.POST['first_name']
        l_name=request.POST['last_name']
        username=request.POST['username']
        password=request.POST['password']
        email = request.POST['email']
        father=request.POST['father_name']
        mother=request.POST['mother_name']
        dob=request.POST['dob']
        occupation=request.POST['occupation']
        city=request.POST['city']
        state=request.POST['state']
        address=request.POST['address']
        zip=request.POST['zip']
        mobile=request.POST['mobileno']
        nationality=request.POST['nationality']
        gender=request.POST['gender']
        religious=request.POST['religious']
        voterid=request.POST['voterid']
        category=request.POST['category']
       

        user=User.objects.create_user(username,email,password)
        user.first_name=f_name
        user.last_name=l_name
        user.save()
        name = f_name+l_name
        userdata = regis_user(name=name,password=password,fathers_name=father,mothers_name=mother,mobileno=mobile,aadharno=username,voter_id=voterid,dob=dob,gender=gender,city=city,State=state,occupation=occupation,address=address,zipcode=zip,nationality=nationality,category=category,Religious=religious)
        userdata.save()
        messages.success(request,'your account is succesfully created !')
        return redirect('login')
    else:

        return render(request,'evote/register.html')

def errorpage(request):
    return render(request,'evote/404error.html')

def result(request):
    return render(request,'evote/result.html')
